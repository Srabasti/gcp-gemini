#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "🎯 RUNNING COMPREHENSIVE DATAFORM MEDALLION EVALUATION"
echo "=========================================================="

echo -e "\n[TEST SUITE 1] Agent Tool & Transformation Logic Unit Tests"
PYTHONPATH=. python3 tests/eval/test_dataform_transformations.py

echo -e "\n[TEST SUITE 2] Live BigQuery Medallion Layer Validation"
python3 tests/eval/test_bigquery_live_eval.py

echo -e "\n=========================================================="
echo "🎉 ALL EVALS PASSED: 100% SUCCESS WITH ZERO REGRESSIONS"
echo "=========================================================="
