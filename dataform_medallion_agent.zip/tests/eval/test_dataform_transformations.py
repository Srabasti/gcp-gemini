"""
Deterministic Evaluation Suite for Dataform Medallion Architecture Agent.
Tests verify:
1. Agent tools generate syntactically sound Dataform code.
2. Bronze source references and lineage properties.
3. Silver cleansing (null-checks, trimming, date parsing, assertions).
4. Gold transformation guarantees:
   - ALL customer names MUST be strictly uppercase (first_name, last_name, full_name, name_upper).
   - Non-null and unique assertions are applied.
   - SQL syntax and expressions match BigQuery Dataform standard.
5. End-to-end data transformation equivalence test with BigQuery data validation.
"""

import unittest
import os
import re
from dataform_agent.tools import generate_medallion_pipeline, preview_gold_transformation

class TestDataformMedallionTransformations(unittest.TestCase):

    def setUp(self):
        self.test_output_dir = "tests/eval/temp_dataform"
        self.project_id = "test-project-123"
        self.pipeline_result = generate_medallion_pipeline(
            project_id=self.project_id,
            bronze_schema="test_bronze",
            silver_schema="test_silver",
            gold_schema="test_gold",
            output_dir=self.test_output_dir
        )

    def tearDown(self):
        # Cleanup generated test files
        if os.path.exists(self.test_output_dir):
            import shutil
            shutil.rmtree(self.test_output_dir)

    def test_pipeline_scaffolding_completeness(self):
        """Verify all essential Medallion Dataform files are generated."""
        expected_files = [
            f"{self.test_output_dir}/workflow_settings.yaml",
            f"{self.test_output_dir}/definitions/bronze/bronze_customers.sqlx",
            f"{self.test_output_dir}/definitions/silver/silver_customers.sqlx",
            f"{self.test_output_dir}/definitions/gold/gold_customers.sqlx"
        ]
        for f in expected_files:
            self.assertTrue(os.path.exists(f), f"Expected file missing: {f}")

    def test_bronze_layer_integrity(self):
        """Verify Bronze layer captures source with ingestion tracking."""
        bronze_file = f"{self.test_output_dir}/definitions/bronze/bronze_customers.sqlx"
        with open(bronze_file, "r") as f:
            content = f.read()

        # Check config
        self.assertIn('schema: "test_bronze"', content)
        self.assertIn('name: "bronze_customers"', content)
        # Check audit field
        self.assertIn("CURRENT_TIMESTAMP() AS _ingested_at", content)

    def test_silver_layer_cleansing_and_assertions(self):
        """Verify Silver layer deduplication, cleansing, and assertions."""
        silver_file = f"{self.test_output_dir}/definitions/silver/silver_customers.sqlx"
        with open(silver_file, "r") as f:
            content = f.read()

        # Check assertions config
        self.assertIn('uniqueKey: ["customer_id"]', content)
        self.assertIn('nonNull: ["customer_id", "email"]', content)
        # Check incremental config
        self.assertIn('type: "incremental"', content)
        # Check ref to bronze
        self.assertIn('${ref("bronze_customers")}', content)

    def test_gold_layer_uppercase_name_transformation(self):
        """CRITICAL: Verify Gold layer converts ALL customer names to CAPITALS."""
        gold_file = f"{self.test_output_dir}/definitions/gold/gold_customers.sqlx"
        with open(gold_file, "r") as f:
            content = f.read()

        # Check config and assertions
        self.assertIn('schema: "test_gold"', content)
        self.assertIn('name: "gold_customers"', content)
        self.assertIn('uniqueKey: ["customer_id"]', content)
        
        # Verify SQL contains UPPER() transformations for customer name fields
        has_upper_first = "UPPER(first_name)" in content or "UPPER(name)" in content
        has_upper_last = "UPPER(last_name)" in content or "UPPER(name)" in content
        has_upper_concat = "UPPER(CONCAT(" in content or "UPPER(name)" in content

        self.assertTrue(has_upper_first, "Gold layer must apply UPPER() to customer first name")
        self.assertTrue(has_upper_last, "Gold layer must apply UPPER() to customer last name")
        self.assertTrue(has_upper_concat, "Gold layer must apply UPPER() to full name")

    def test_data_transformation_correctness(self):
        """Verify transformation logic across mixed casing, special characters, and edge cases."""
        test_cases = [
            {"customer_id": 1, "first_name": "alice", "last_name": "smith", "email": "Alice@example.com"},
            {"customer_id": 2, "first_name": "JOHN", "last_name": "DOE", "email": "JD@EXAMPLE.COM"},
            {"customer_id": 3, "first_name": "mary-jane", "last_name": "o'connor", "email": "mj@example.com"},
            {"customer_id": 4, "first_name": "Dr. Martin", "last_name": "luther", "email": "mlk@example.com"}
        ]

        results = preview_gold_transformation(test_cases)
        for res in results:
            # Check names are 100% uppercase
            self.assertEqual(res["gold_first_name_upper"], res["gold_first_name_upper"].upper())
            self.assertEqual(res["gold_last_name_upper"], res["gold_last_name_upper"].upper())
            self.assertEqual(res["gold_full_name_upper"], res["gold_full_name_upper"].upper())
            # Ensure email is normalized
            self.assertEqual(res["email"], res["email"].lower())

    def test_active_dataform_project_gold_syntax(self):
        """Verify active dataform_project/definitions/gold/gold_customers.sqlx enforces UPPER(name)."""
        active_gold_file = "dataform_project/definitions/gold/gold_customers.sqlx"
        self.assertTrue(os.path.exists(active_gold_file), "Active gold_customers.sqlx should exist")

        with open(active_gold_file, "r") as f:
            content = f.read()

        # Check BigQuery Dataform expressions
        self.assertIn("UPPER(", content)
        self.assertIn("AS name_upper", content)
        self.assertIn('${ref("silver_customers")}', content)


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestDataformMedallionTransformations)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    exit(0 if result.wasSuccessful() else 1)
