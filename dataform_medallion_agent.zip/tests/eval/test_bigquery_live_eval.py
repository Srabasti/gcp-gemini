"""
Live BigQuery Evaluation Suite:
Directly queries the deployed BigQuery Medallion tables:
1. bronze_dataset.bronze_customers
2. silver_dataset.silver_customers
3. gold_dataset.gold_customers

Validates:
- Row counts match across Bronze -> Silver -> Gold (no dropped records).
- All customer names in Gold are strictly uppercase: name_upper == UPPER(name_upper).
- No null or empty names in Gold.
- Data types are consistent (NUMERIC lifetime_value, DATE last_purchase_date).
"""

import subprocess
import json
import unittest

PROJECT_ID = "qwiklabs-gcp-01-213bcdb9ce9c"

def run_bq_query(query: str):
    cmd = [
        "bq", "query",
        "--use_legacy_sql=false",
        "--format=json",
        query
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"BQ query failed: {res.stderr}")
    return json.loads(res.stdout)

class TestBigQueryMedallionLive(unittest.TestCase):

    def test_row_counts_across_layers(self):
        """Ensure all records flow from Bronze to Silver and to Gold without loss."""
        bronze_count = run_bq_query(f"SELECT COUNT(*) as cnt FROM `{PROJECT_ID}.bronze_dataset.bronze_customers`")[0]["cnt"]
        silver_count = run_bq_query(f"SELECT COUNT(*) as cnt FROM `{PROJECT_ID}.silver_dataset.silver_customers`")[0]["cnt"]
        gold_count = run_bq_query(f"SELECT COUNT(*) as cnt FROM `{PROJECT_ID}.gold_dataset.gold_customers`")[0]["cnt"]

        self.assertEqual(bronze_count, silver_count, "Silver record count must match Bronze")
        self.assertEqual(silver_count, gold_count, "Gold record count must match Silver")
        print(f"\n[EVAL] Row Count Consistency Verified: {gold_count} records across all 3 layers.")

    def test_gold_names_are_all_strictly_uppercase(self):
        """Verify 100% of customer names in Gold layer are capitalized."""
        query = f"""
        SELECT 
            COUNT(*) as total_records,
            COUNTIF(name_upper != UPPER(name_upper)) as non_uppercase_count,
            COUNTIF(name_upper IS NULL OR name_upper = '') as empty_name_count
        FROM `{PROJECT_ID}.gold_dataset.gold_customers`
        """
        result = run_bq_query(query)[0]
        total = int(result["total_records"])
        non_upper = int(result["non_uppercase_count"])
        empty_names = int(result["empty_name_count"])

        self.assertGreater(total, 0, "Gold table must have records")
        self.assertEqual(non_upper, 0, f"Found {non_upper} names that are NOT all uppercase!")
        self.assertEqual(empty_names, 0, f"Found {empty_names} names that are null or empty!")
        print(f"[EVAL] Upper Case Name Verification: {total}/{total} records strictly in ALL CAPS.")

    def test_gold_vs_source_name_comparison(self):
        """Spot check comparison between original source name and Gold transformed name."""
        query = f"""
        SELECT 
            b.customer_id,
            b.name AS raw_name,
            g.name_upper AS gold_name
        FROM `{PROJECT_ID}.bronze_dataset.bronze_customers` b
        JOIN `{PROJECT_ID}.gold_dataset.gold_customers` g ON b.customer_id = g.customer_id
        LIMIT 5
        """
        rows = run_bq_query(query)
        for r in rows:
            raw = r["raw_name"]
            gold = r["gold_name"]
            self.assertEqual(gold, raw.upper(), f"Mismatch: Raw '{raw}' != Gold '{gold}'")
            print(f"[EVAL] Transformation Verified: '{raw}' -> '{gold}'")

if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestBigQueryMedallionLive)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    exit(0 if result.wasSuccessful() else 1)
