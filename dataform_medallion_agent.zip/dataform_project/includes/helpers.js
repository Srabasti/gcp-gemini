/**
 * Shared JavaScript helper functions for Dataform transformations.
 */

function capitalizeName(columnName) {
  return `UPPER(TRIM(${columnName}))`;
}

function fullUpperName(firstNameCol, lastNameCol) {
  return `UPPER(CONCAT(TRIM(${firstNameCol}), ' ', TRIM(${lastNameCol})))`;
}

module.exports = {
  capitalizeName,
  fullUpperName
};
