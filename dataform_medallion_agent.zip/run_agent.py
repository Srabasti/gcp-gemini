#!/usr/bin/env python3
"""
Verification and Demo Script for Dataform Medallion Architecture Agent.
"""

import json
from dataform_agent.tools import generate_medallion_pipeline, preview_gold_transformation

def main():
    print("=" * 60)
    print("🚀 Running Dataform Medallion Architecture Agent Tools")
    print("=" * 60)

    # 1. Preview transformation logic
    print("\n[Step 1] Previewing Customer Name Transformation into Gold Layer:")
    preview = preview_gold_transformation([
        {"customer_id": 101, "first_name": "jane", "last_name": "doe", "email": "Jane.Doe@EXAMPLE.COM"},
        {"customer_id": 102, "first_name": "marcus", "last_name": "aurelius", "email": "marcus@rome.org"}
    ])
    print(json.dumps(preview, indent=2))

    # 2. Generate Dataform Medallion Layer
    print("\n[Step 2] Generating Complete Dataform Project Definitions:")
    result = generate_medallion_pipeline(
        project_id="novasmart-ai-analytics",
        bronze_schema="bronze_dataset",
        silver_schema="silver_dataset",
        gold_schema="gold_dataset",
        output_dir="dataform_project"
    )
    print(json.dumps(result, indent=2))

    print("\n[Step 3] Inspecting Gold Layer SQLX Definition:")
    with open("dataform_project/definitions/gold/gold_customers.sqlx") as f:
        print(f.read())

    print("\n✅ All operations completed successfully!")

if __name__ == "__main__":
    main()
