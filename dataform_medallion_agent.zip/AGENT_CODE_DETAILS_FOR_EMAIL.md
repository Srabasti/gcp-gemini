# Dataform Medallion Architecture Agent - Code Details (With Integrated Evals)

**Recipient**: srabasti.banerjee@66degrees.com  
**Project**: `qwiklabs-gcp-01-213bcdb9ce9c`  
**Agent Registry Resource**: `projects/qwiklabs-gcp-01-213bcdb9ce9c/locations/us-west1/agents/agentregistry-00000000-0000-0000-d786-dc6c26c1c7d7`

---

## 1. Agent Definition With Integrated Evals (`dataform_agent/agent.py`)

```python
"""
Dataform Medallion Architecture Agent.
Specialized ADK agent that builds, manages, executes, and evaluates Dataform pipelines for Medallion architecture.
"""

from google.adk.agents import Agent
from dataform_agent.tools import generate_medallion_pipeline, preview_gold_transformation
from dataform_agent.eval_tools import evaluate_dataform_project_definitions, evaluate_live_medallion_tables

SYSTEM_INSTRUCTION = """
You are the Dataform Medallion Architecture Specialist.
Your mission is to help data engineering and analytics teams implement, maintain, and rigorously evaluate robust Medallion architectures (Bronze, Silver, Gold) in BigQuery using Dataform.

Key transformation rules:
1. Bronze Layer: Raw ingestion preserving source fidelity, source timestamps, and raw fields.
2. Silver Layer: Cleaned, deduplicated, validated, and normalized schema.
3. Gold Layer: Aggregated, curated business reporting data. For customer dimensions, ensure that all customer names are capitalized (UPPER(name) AS name_upper).
4. Assertions: Always attach data quality assertions (uniqueKey, nonNull) to ensure high data integrity.

Evaluation capabilities:
- You can run deterministic project definition evals (`evaluate_dataform_project_definitions`) to verify that all SQLX files, syntax, and UPPER() transformations are correctly declared.
- You can run live BigQuery validation evals (`evaluate_live_medallion_tables`) to prove zero data loss and 100% uppercase compliance in the materialized Gold layer.
"""

def create_agent() -> Agent:
    return Agent(
        name="DataformMedallionAgent",
        model="gemini-2.5-flash",
        description="Agent for creating, managing, and evaluating Dataform Medallion architectures in BigQuery with transformed customer Gold layers.",
        instruction=SYSTEM_INSTRUCTION,
        tools=[
            generate_medallion_pipeline,
            preview_gold_transformation,
            evaluate_dataform_project_definitions,
            evaluate_live_medallion_tables
        ]
    )

agent = create_agent()
```

---

## 2. Agent Eval Tools Module (`dataform_agent/eval_tools.py`)

```python
"""
Dataform Medallion Architecture Evaluation Tools.
Provides native evaluation methods directly attached to the agent to verify:
1. SQLX Medallion scaffolding completeness.
2. Gold layer uppercase name compliance.
3. BigQuery data integrity and zero-data-loss validation.
"""

import os
import subprocess
import json
from typing import Dict, Any

def evaluate_dataform_project_definitions(project_dir: str = "dataform_project") -> Dict[str, Any]:
    results = {
        "passed": True,
        "scaffolding_checks": {},
        "gold_transformation_checks": {},
        "errors": []
    }
    required_files = [
        f"{project_dir}/workflow_settings.yaml",
        f"{project_dir}/definitions/bronze/bronze_customers.sqlx",
        f"{project_dir}/definitions/silver/silver_customers.sqlx",
        f"{project_dir}/definitions/gold/gold_customers.sqlx"
    ]
    for rf in required_files:
        exists = os.path.exists(rf)
        results["scaffolding_checks"][os.path.basename(rf)] = exists
        if not exists:
            results["passed"] = False
            results["errors"].append(f"Missing required definition file: {rf}")

    gold_file = f"{project_dir}/definitions/gold/gold_customers.sqlx"
    if os.path.exists(gold_file):
        with open(gold_file, "r") as f:
            gold_sql = f.read()
        has_upper = "UPPER(name)" in gold_sql or "UPPER(first_name)" in gold_sql
        results["gold_transformation_checks"]["has_upper_transformation"] = has_upper
        results["gold_transformation_checks"]["has_unique_key_assertion"] = 'uniqueKey: ["customer_id"]' in gold_sql
        results["gold_transformation_checks"]["has_non_null_assertion"] = 'nonNull: [' in gold_sql
        if not has_upper:
            results["passed"] = False
            results["errors"].append("Gold layer does not enforce uppercase transformation (UPPER) on customer names.")
    else:
        results["passed"] = False

    return results

def evaluate_live_medallion_tables(project_id: str = "qwiklabs-gcp-01-213bcdb9ce9c") -> Dict[str, Any]:
    results = {
        "passed": True,
        "metrics": {},
        "errors": []
    }
    try:
        count_query = f"""
        SELECT 
            (SELECT COUNT(*) FROM `{project_id}.bronze_dataset.bronze_customers`) AS bronze_cnt,
            (SELECT COUNT(*) FROM `{project_id}.silver_dataset.silver_customers`) AS silver_cnt,
            (SELECT COUNT(*) FROM `{project_id}.gold_dataset.gold_customers`) AS gold_cnt
        """
        cmd = ["bq", "query", "--use_legacy_sql=false", "--format=json", count_query]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        counts = json.loads(res.stdout)[0]
        b_cnt, s_cnt, g_cnt = int(counts["bronze_cnt"]), int(counts["silver_cnt"]), int(counts["gold_cnt"])
        results["metrics"]["row_counts"] = {"bronze": b_cnt, "silver": s_cnt, "gold": g_cnt}
        if not (b_cnt == s_cnt == g_cnt):
            results["passed"] = False
            results["errors"].append(f"Row count mismatch across layers: Bronze={b_cnt}, Silver={s_cnt}, Gold={g_cnt}")

        upper_query = f"""
        SELECT 
            COUNT(*) as total_records,
            COUNTIF(name_upper != UPPER(name_upper)) as non_uppercase_count,
            COUNTIF(name_upper IS NULL OR name_upper = '') as empty_name_count
        FROM `{project_id}.gold_dataset.gold_customers`
        """
        cmd_upper = ["bq", "query", "--use_legacy_sql=false", "--format=json", upper_query]
        res_upper = subprocess.run(cmd_upper, capture_output=True, text=True, check=True)
        upper_stats = json.loads(res_upper.stdout)[0]
        total = int(upper_stats["total_records"])
        non_upper = int(upper_stats["non_uppercase_count"])
        empty = int(upper_stats["empty_name_count"])

        results["metrics"]["total_customers"] = total
        results["metrics"]["non_uppercase_names"] = non_upper
        results["metrics"]["empty_names"] = empty
        results["metrics"]["uppercase_compliance_pct"] = 100.0 if total > 0 and non_upper == 0 else 0.0

        if non_upper > 0:
            results["passed"] = False
            results["errors"].append(f"Found {non_upper} non-uppercase customer names in Gold layer!")
        if empty > 0:
            results["passed"] = False
            results["errors"].append(f"Found {empty} empty customer names in Gold layer!")
    except Exception as e:
        results["passed"] = False
        results["errors"].append(str(e))

    return results
```

---

## 3. Dataform SQLX Definitions (`dataform_project/`)

### Bronze Source Declaration (`bronze_customers.sqlx`)
```sql
config {
  type: "declaration",
  database: "qwiklabs-gcp-01-213bcdb9ce9c",
  schema: "customer_data",
  name: "customers",
  description: "Raw customer profile table from source system (Bronze layer source)"
}
```

### Silver Incremental Cleansing (`silver_customers.sqlx`)
```sql
config {
  type: "incremental",
  schema: "silver_dataset",
  name: "silver_customers",
  description: "Cleaned, standardized, and validated customer profile records (Silver layer).",
  uniqueKey: ["customer_id"],
  assertions: {
    uniqueKey: ["customer_id"],
    nonNull: ["customer_id", "email"]
  },
  tags: ["silver", "customers"]
}

SELECT
  customer_id,
  TRIM(name) AS name,
  LOWER(TRIM(email)) AS email,
  loyalty_tier,
  CAST(lifetime_value AS NUMERIC) AS lifetime_value,
  preferred_category,
  SAFE.PARSE_DATE('%Y-%m-%d', last_purchase_date) AS last_purchase_date,
  CURRENT_TIMESTAMP() AS _processed_at
FROM
  ${ref("customers")}
WHERE
  customer_id IS NOT NULL

${when(incremental(), `AND _processed_at > (SELECT MAX(_processed_at) FROM ${self()})`)}
```

### Gold Dimension Table (`gold_customers.sqlx`)
```sql
config {
  type: "table",
  schema: "gold_dataset",
  name: "gold_customers",
  description: "Curated customer analytics dimension table (Gold layer) with all customer names transformed to ALL CAPITALS.",
  assertions: {
    uniqueKey: ["customer_id"],
    nonNull: ["customer_id", "name_upper"]
  },
  tags: ["gold", "customers", "analytics", "medallion"]
}

SELECT
  customer_id,
  -- TRANSFORMATION REQUIREMENT: ALL NAMES IN CAPITALS
  UPPER(name) AS name_upper,
  email,
  loyalty_tier,
  lifetime_value,
  preferred_category,
  last_purchase_date,
  CURRENT_TIMESTAMP() AS _gold_updated_at
FROM
  ${ref("silver_customers")}
```

---

## 4. Agent Registry Verification
The agent in Google Cloud Agent Registry now exposes 4 registered skills including both eval skills:
- `generate_medallion_pipeline`
- `preview_gold_transformation`
- `evaluate_dataform_project_definitions`
- `evaluate_live_medallion_tables`
