"""
Dataform Medallion Architecture Agent Tools.
Provides utilities to scaffold, inspect, and generate Dataform definitions for BigQuery.
"""

import os
from typing import Dict, Any, List

def generate_medallion_pipeline(
    project_id: str = "gcp-project-id",
    bronze_schema: str = "bronze",
    silver_schema: str = "silver",
    gold_schema: str = "gold",
    output_dir: str = "generated_dataform"
) -> Dict[str, Any]:
    """
    Generates a full Dataform Medallion project with Bronze, Silver, and Gold transformations.
    Ensures that customer names in the Gold layer are converted to uppercase.
    """
    os.makedirs(f"{output_dir}/definitions/bronze", exist_ok=True)
    os.makedirs(f"{output_dir}/definitions/silver", exist_ok=True)
    os.makedirs(f"{output_dir}/definitions/gold", exist_ok=True)
    os.makedirs(f"{output_dir}/includes", exist_ok=True)

    # 1. workflow_settings.yaml
    workflow_yaml = f"""defaultProject: "{project_id}"
defaultDataset: "dataform"
defaultLocation: "US"
defaultAssertionDataset: "dataform_assertions"
dataformCoreVersion: "3.0.0"
"""
    with open(f"{output_dir}/workflow_settings.yaml", "w") as f:
        f.write(workflow_yaml)

    # 2. Bronze Layer
    bronze_sqlx = f"""config {{
  type: "table",
  schema: "{bronze_schema}",
  name: "bronze_customers",
  description: "Raw customer data ingestion",
  tags: ["bronze", "customers"]
}}

SELECT
  CAST(customer_id AS INT64) AS customer_id,
  TRIM(first_name) AS first_name,
  TRIM(last_name) AS last_name,
  TRIM(email) AS email,
  phone_number,
  address,
  city,
  country,
  CAST(created_at AS TIMESTAMP) AS created_at,
  CURRENT_TIMESTAMP() AS _ingested_at
FROM
  -- Simulated raw source
  (
    SELECT 1 AS customer_id, 'alice' AS first_name, 'smith' AS last_name, 'alice@example.com' AS email, '+15550101' AS phone_number, '123 Market St' AS address, 'San Francisco' AS city, 'USA' AS country, TIMESTAMP('2024-01-15') AS created_at
    UNION ALL
    SELECT 2, 'bob', 'jones', 'bob@example.com', '+15550102', '456 Elm Ave', 'Austin', 'USA', TIMESTAMP('2024-02-01')
    UNION ALL
    SELECT 3, 'charlie', 'brown', 'charlie@example.com', '+15550103', '789 Oak Rd', 'Seattle', 'USA', TIMESTAMP('2024-02-10')
  )
"""
    with open(f"{output_dir}/definitions/bronze/bronze_customers.sqlx", "w") as f:
        f.write(bronze_sqlx)

    # 3. Silver Layer
    silver_sqlx = f"""config {{
  type: "incremental",
  schema: "{silver_schema}",
  name: "silver_customers",
  description: "Cleaned and standardized customer records",
  uniqueKey: ["customer_id"],
  assertions: {{
    uniqueKey: ["customer_id"],
    nonNull: ["customer_id", "email"]
  }},
  tags: ["silver", "customers"]
}}

SELECT
  customer_id,
  COALESCE(NULLIF(TRIM(first_name), ''), 'UNKNOWN') AS first_name,
  COALESCE(NULLIF(TRIM(last_name), ''), 'UNKNOWN') AS last_name,
  LOWER(TRIM(email)) AS email,
  REGEXP_REPLACE(phone_number, r'[^0-9+]', '') AS phone_number,
  TRIM(address) AS address,
  INITCAP(TRIM(city)) AS city,
  UPPER(TRIM(country)) AS country_code,
  created_at,
  CURRENT_TIMESTAMP() AS _processed_at
FROM
  ${{ref("bronze_customers")}}
WHERE
  customer_id IS NOT NULL
"""
    with open(f"{output_dir}/definitions/silver/silver_customers.sqlx", "w") as f:
        f.write(silver_sqlx)

    # 4. Gold Layer (Transformed with UPPER / Capitals)
    gold_sqlx = f"""config {{
  type: "table",
  schema: "{gold_schema}",
  name: "gold_customers",
  description: "Curated customer dimension table with all names converted to CAPITALS",
  columns: {{
    customer_id: "Unique primary identifier for customer",
    first_name_upper: "First name capitalized",
    last_name_upper: "Last name capitalized",
    full_name_upper: "Full name capitalized (CONCAT)",
    email: "Customer email",
    city: "Customer resident city",
    country_code: "Country code",
    customer_tenure_days: "Customer tenure in days",
    _gold_updated_at: "Gold materialization timestamp"
  }},
  assertions: {{
    uniqueKey: ["customer_id"],
    nonNull: ["customer_id", "first_name_upper", "last_name_upper", "full_name_upper"]
  }},
  tags: ["gold", "customers", "analytics"]
}}

SELECT
  customer_id,
  -- All customer names transformed to CAPITALS
  UPPER(first_name) AS first_name_upper,
  UPPER(last_name) AS last_name_upper,
  UPPER(CONCAT(first_name, ' ', last_name)) AS full_name_upper,
  email,
  phone_number,
  address,
  city,
  country_code,
  created_at,
  DATE_DIFF(CURRENT_DATE(), DATE(created_at), DAY) AS customer_tenure_days,
  CURRENT_TIMESTAMP() AS _gold_updated_at
FROM
  ${{ref("silver_customers")}}
"""
    with open(f"{output_dir}/definitions/gold/gold_customers.sqlx", "w") as f:
        f.write(gold_sqlx)

    return {
        "status": "success",
        "output_directory": output_dir,
        "files_generated": [
            f"{output_dir}/workflow_settings.yaml",
            f"{output_dir}/definitions/bronze/bronze_customers.sqlx",
            f"{output_dir}/definitions/silver/silver_customers.sqlx",
            f"{output_dir}/definitions/gold/gold_customers.sqlx"
        ],
        "gold_transformation": "Customer names transformed via UPPER(first_name), UPPER(last_name), and UPPER(CONCAT(...))"
    }

def preview_gold_transformation(sample_customers: List[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """
    Demonstrates the exact transformation logic from Bronze/Silver to Gold.
    Converts first_name, last_name, and full_name to capitals.
    """
    if not sample_customers:
        sample_customers = [
            {"customer_id": 1, "first_name": "alice", "last_name": "smith", "email": "alice@example.com"},
            {"customer_id": 2, "first_name": "bob", "last_name": "jones", "email": "bob@example.com"},
            {"customer_id": 3, "first_name": "charlie", "last_name": "brown", "email": "charlie@example.com"}
        ]
    
    transformed = []
    for c in sample_customers:
        fn = c.get("first_name", "")
        ln = c.get("last_name", "")
        transformed.append({
            "customer_id": c.get("customer_id"),
            "original_first_name": fn,
            "original_last_name": ln,
            "gold_first_name_upper": fn.upper(),
            "gold_last_name_upper": ln.upper(),
            "gold_full_name_upper": f"{fn} {ln}".upper(),
            "email": c.get("email", "").lower()
        })
    return transformed
