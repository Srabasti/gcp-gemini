"""
Dataform Medallion Architecture Evaluation Tools.
Provides native evaluation methods directly attached to the agent to verify:
1. SQLX Medallion scaffolding completeness.
2. Gold layer uppercase name compliance.
3. BigQuery data integrity and zero-data-loss validation.
"""

import os
import subprocess
import json
from typing import Dict, Any, List

def evaluate_dataform_project_definitions(project_dir: str = "dataform_project") -> Dict[str, Any]:
    """
    Evaluates the static syntax, scaffolding completeness, and uppercase transformation rules
    in the Dataform repository definitions.
    """
    results = {
        "passed": True,
        "scaffolding_checks": {},
        "gold_transformation_checks": {},
        "errors": []
    }

    required_files = [
        f"{project_dir}/workflow_settings.yaml",
        f"{project_dir}/definitions/bronze/bronze_customers.sqlx",
        f"{project_dir}/definitions/silver/silver_customers.sqlx",
        f"{project_dir}/definitions/gold/gold_customers.sqlx"
    ]

    for rf in required_files:
        exists = os.path.exists(rf)
        results["scaffolding_checks"][os.path.basename(rf)] = exists
        if not exists:
            results["passed"] = False
            results["errors"].append(f"Missing required definition file: {rf}")

    # Inspect Gold Layer SQLX
    gold_file = f"{project_dir}/definitions/gold/gold_customers.sqlx"
    if os.path.exists(gold_file):
        with open(gold_file, "r") as f:
            gold_sql = f.read()

        has_upper = "UPPER(name)" in gold_sql or "UPPER(first_name)" in gold_sql
        results["gold_transformation_checks"]["has_upper_transformation"] = has_upper
        results["gold_transformation_checks"]["has_unique_key_assertion"] = 'uniqueKey: ["customer_id"]' in gold_sql
        results["gold_transformation_checks"]["has_non_null_assertion"] = 'nonNull: [' in gold_sql

        if not has_upper:
            results["passed"] = False
            results["errors"].append("Gold layer does not enforce uppercase transformation (UPPER) on customer names.")
    else:
        results["passed"] = False

    return results

def evaluate_live_medallion_tables(project_id: str = "qwiklabs-gcp-01-213bcdb9ce9c") -> Dict[str, Any]:
    """
    Executes live verification queries against BigQuery Bronze, Silver, and Gold tables
    to mathematically verify:
    1. Zero record loss (count(Bronze) == count(Silver) == count(Gold)).
    2. 100% of customer names in Gold table are uppercase.
    3. No null or empty names in Gold.
    """
    results = {
        "passed": True,
        "metrics": {},
        "errors": []
    }

    try:
        # Check counts
        count_query = f"""
        SELECT 
            (SELECT COUNT(*) FROM `{project_id}.bronze_dataset.bronze_customers`) AS bronze_cnt,
            (SELECT COUNT(*) FROM `{project_id}.silver_dataset.silver_customers`) AS silver_cnt,
            (SELECT COUNT(*) FROM `{project_id}.gold_dataset.gold_customers`) AS gold_cnt
        """
        cmd = ["bq", "query", "--use_legacy_sql=false", "--format=json", count_query]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        counts = json.loads(res.stdout)[0]

        b_cnt = int(counts["bronze_cnt"])
        s_cnt = int(counts["silver_cnt"])
        g_cnt = int(counts["gold_cnt"])

        results["metrics"]["row_counts"] = {"bronze": b_cnt, "silver": s_cnt, "gold": g_cnt}
        if not (b_cnt == s_cnt == g_cnt):
            results["passed"] = False
            results["errors"].append(f"Row count mismatch across layers: Bronze={b_cnt}, Silver={s_cnt}, Gold={g_cnt}")

        # Check Uppercase Compliance in Gold
        upper_query = f"""
        SELECT 
            COUNT(*) as total_records,
            COUNTIF(name_upper != UPPER(name_upper)) as non_uppercase_count,
            COUNTIF(name_upper IS NULL OR name_upper = '') as empty_name_count
        FROM `{project_id}.gold_dataset.gold_customers`
        """
        cmd_upper = ["bq", "query", "--use_legacy_sql=false", "--format=json", upper_query]
        res_upper = subprocess.run(cmd_upper, capture_output=True, text=True, check=True)
        upper_stats = json.loads(res_upper.stdout)[0]

        total = int(upper_stats["total_records"])
        non_upper = int(upper_stats["non_uppercase_count"])
        empty = int(upper_stats["empty_name_count"])

        results["metrics"]["total_customers"] = total
        results["metrics"]["non_uppercase_names"] = non_upper
        results["metrics"]["empty_names"] = empty
        results["metrics"]["uppercase_compliance_pct"] = 100.0 if total > 0 and non_upper == 0 else 0.0

        if non_upper > 0:
            results["passed"] = False
            results["errors"].append(f"Found {non_upper} non-uppercase customer names in Gold layer!")
        if empty > 0:
            results["passed"] = False
            results["errors"].append(f"Found {empty} empty customer names in Gold layer!")

    except Exception as e:
        results["passed"] = False
        results["errors"].append(str(e))

    return results
