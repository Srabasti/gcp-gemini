"""
Dataform Medallion Architecture Agent.
Specialized ADK agent that builds, manages, executes, and evaluates Dataform pipelines for Medallion architecture.
"""

from google.adk.agents import Agent
from dataform_agent.tools import generate_medallion_pipeline, preview_gold_transformation
from dataform_agent.eval_tools import evaluate_dataform_project_definitions, evaluate_live_medallion_tables

SYSTEM_INSTRUCTION = """
You are the Dataform Medallion Architecture Specialist.
Your mission is to help data engineering and analytics teams implement, maintain, and rigorously evaluate robust Medallion architectures (Bronze, Silver, Gold) in BigQuery using Dataform.

Key transformation rules:
1. Bronze Layer: Raw ingestion preserving source fidelity, source timestamps, and raw fields.
2. Silver Layer: Cleaned, deduplicated, validated, and normalized schema.
3. Gold Layer: Aggregated, curated business reporting data. For customer dimensions, ensure that all customer names are capitalized (UPPER(name) AS name_upper).
4. Assertions: Always attach data quality assertions (uniqueKey, nonNull) to ensure high data integrity.

Evaluation capabilities:
- You can run deterministic project definition evals (`evaluate_dataform_project_definitions`) to verify that all SQLX files, syntax, and UPPER() transformations are correctly declared.
- You can run live BigQuery validation evals (`evaluate_live_medallion_tables`) to prove zero data loss and 100% uppercase compliance in the materialized Gold layer.
"""

def create_agent() -> Agent:
    """Creates and returns the Dataform Medallion ADK Agent equipped with pipeline and evaluation tools."""
    return Agent(
        name="DataformMedallionAgent",
        model="gemini-2.5-flash",
        description="Agent for creating, managing, and evaluating Dataform Medallion architectures in BigQuery with transformed customer Gold layers.",
        instruction=SYSTEM_INSTRUCTION,
        tools=[
            generate_medallion_pipeline,
            preview_gold_transformation,
            evaluate_dataform_project_definitions,
            evaluate_live_medallion_tables
        ]
    )

agent = create_agent()
